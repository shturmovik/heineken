﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.FindFIO = new System.Windows.Forms.TextBox();
            this.Find = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.FIO = new System.Windows.Forms.TextBox();
            this.MobileNum = new System.Windows.Forms.TextBox();
            this.HomeNum = new System.Windows.Forms.TextBox();
            this.BDate = new System.Windows.Forms.TextBox();
            this.Write = new System.Windows.Forms.Button();
            this.Delete = new System.Windows.Forms.Button();
            this.ФИО = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // FindFIO
            // 
            this.FindFIO.Location = new System.Drawing.Point(12, 12);
            this.FindFIO.Name = "FindFIO";
            this.FindFIO.Size = new System.Drawing.Size(337, 20);
            this.FindFIO.TabIndex = 0;
            // 
            // Find
            // 
            this.Find.Location = new System.Drawing.Point(355, 12);
            this.Find.Name = "Find";
            this.Find.Size = new System.Drawing.Size(53, 20);
            this.Find.TabIndex = 1;
            this.Find.Text = "Поиск";
            this.Find.UseVisualStyleBackColor = true;
            this.Find.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 38);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(396, 229);
            this.dataGridView1.TabIndex = 2;
            // 
            // FIO
            // 
            this.FIO.Location = new System.Drawing.Point(52, 273);
            this.FIO.Name = "FIO";
            this.FIO.Size = new System.Drawing.Size(356, 20);
            this.FIO.TabIndex = 3;
            this.FIO.TextChanged += new System.EventHandler(this.FIO_TextChanged);
            // 
            // MobileNum
            // 
            this.MobileNum.Location = new System.Drawing.Point(115, 299);
            this.MobileNum.Name = "MobileNum";
            this.MobileNum.Size = new System.Drawing.Size(293, 20);
            this.MobileNum.TabIndex = 4;
            // 
            // HomeNum
            // 
            this.HomeNum.Location = new System.Drawing.Point(115, 325);
            this.HomeNum.Name = "HomeNum";
            this.HomeNum.Size = new System.Drawing.Size(293, 20);
            this.HomeNum.TabIndex = 5;
            // 
            // BDate
            // 
            this.BDate.Location = new System.Drawing.Point(115, 351);
            this.BDate.Name = "BDate";
            this.BDate.Size = new System.Drawing.Size(293, 20);
            this.BDate.TabIndex = 6;
            // 
            // Write
            // 
            this.Write.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.Write.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Write.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Write.Location = new System.Drawing.Point(12, 467);
            this.Write.Name = "Write";
            this.Write.Size = new System.Drawing.Size(189, 35);
            this.Write.TabIndex = 7;
            this.Write.Text = "Записать";
            this.Write.UseVisualStyleBackColor = false;
            this.Write.Click += new System.EventHandler(this.button2_Click);
            // 
            // Delete
            // 
            this.Delete.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Delete.DialogResult = System.Windows.Forms.DialogResult.Abort;
            this.Delete.Location = new System.Drawing.Point(219, 467);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(189, 35);
            this.Delete.TabIndex = 8;
            this.Delete.Text = "Удалить";
            this.Delete.UseVisualStyleBackColor = false;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // ФИО
            // 
            this.ФИО.AutoSize = true;
            this.ФИО.Location = new System.Drawing.Point(12, 276);
            this.ФИО.Name = "ФИО";
            this.ФИО.Size = new System.Drawing.Size(34, 13);
            this.ФИО.TabIndex = 9;
            this.ФИО.Text = "ФИО";
            this.ФИО.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ФИО.Click += new System.EventHandler(this.label1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 302);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Мобильный номер";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 328);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Домашний номер";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 354);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Дата рождения";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 514);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ФИО);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.Write);
            this.Controls.Add(this.BDate);
            this.Controls.Add(this.HomeNum);
            this.Controls.Add(this.MobileNum);
            this.Controls.Add(this.FIO);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Find);
            this.Controls.Add(this.FindFIO);
            this.Name = "Form1";
            this.Text = "Телефонный справочник";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox FindFIO;
        private System.Windows.Forms.Button Find;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox FIO;
        private System.Windows.Forms.TextBox MobileNum;
        private System.Windows.Forms.TextBox HomeNum;
        private System.Windows.Forms.TextBox BDate;
        private System.Windows.Forms.Button Write;
        private System.Windows.Forms.Button Delete;
        private System.Windows.Forms.Label ФИО;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

